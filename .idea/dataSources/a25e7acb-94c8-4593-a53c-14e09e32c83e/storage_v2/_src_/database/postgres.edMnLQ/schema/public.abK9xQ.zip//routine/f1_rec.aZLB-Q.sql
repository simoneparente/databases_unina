create procedure f1_rec(IN tagalbum integer)
    language plpgsql
as
$$
    DECLARE
        Album f.album.coda%TYPE;
        output VARCHAR(500);
    BEGIN
        CREATE TABLE f.tmp(codA INTEGER);
        INSERT INTO f.tmp VALUES (tagalbum);
        CALL f2_figli(tagalbum);
        FOR Album IN (SELECT codA FROM f.tmp) LOOP
            output = CONCAT(output, ' ', Album);
        end loop;
        DROP TABLE f.tmp CASCADE;
        RAISE NOTICE '-----------';
        RAISE NOTICE 'Output {%}', output;
    end;
$$;

alter procedure f1_rec(integer) owner to postgres;

