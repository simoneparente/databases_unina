create view recitalabeledv(titolo, id_film, id_attore, nome, cognome) as
SELECT film.titolo,
       film.id_film,
       attore.id_attore,
       attore.nome,
       attore.cognome
FROM cin.film
         JOIN cin.recita ON film.id_film = recita.film
         JOIN cin.attore ON attore.id_attore = recita.attore;

alter table recitalabeledv
    owner to postgres;

