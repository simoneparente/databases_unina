create function funz_1() returns trigger
    language plpgsql
as
$$
        DECLARE
            word r.parolechiave.parola%TYPE;
            cursore CURSOR FOR
                    SELECT parola
                    FROM r.fascicolo NATURAL JOIN r.parolechiave
                    WHERE r.fascicolo.codf=NEW.codf;
            i int:=0;
            n int:=(SELECT COUNT(*)
                   FROM r.fascicolo NATURAL JOIN r.parolechiave);
        BEGIN
            OPEN cursore;
            WHILE (i<n) LOOP
                FETCH cursore into word;

                IF(NEW.sommario LIKE '%' || word || '%') THEN
                    INSERT INTO r.descrizione(parola, doi)
                    values (word, new.doi);

                END IF;
                i=i+1;

            END LOOP;
            CLOSE cursore;
            RETURN NEW;
        END ;
    $$;

alter function funz_1() owner to postgres;

