create function es4(myinput text) returns text
    language plpgsql
as
$$
    DECLARE
        match int;
        myOutput text:= '';
        myParola r.parolechiave.parola%TYPE;
        n_parole int;
        n_doi int := (SELECT COUNT(doi) FROM r.descrizione);
        myDoi r.articolo.doi%TYPE;
        curs_doi cursor for select doi from r.descrizione;
    BEGIN
        open curs_doi;
        --myInput=replace(myInput,'+','@'); --sostituisco '+' con '@' per evitare problemi con la regexp_count
        n_parole := regexp_count(myInput, '\+')+1;
        raise notice '{%}', n_parole;--conto il numero di parole separate da un '@', ovvero il nu mero di '@' + 1
        FOR i IN 1..n_doi LOOP
            FETCH curs_doi INTO myDoi;
            match = 0;
            FOR j IN 1..n_parole LOOP
                MyParola := split_part(myInput, '+', j); --estraggo la j-esima parola
                match:= match + (SELECT COUNT(*) FROM r.descrizione WHERE descrizione.parola = MyParola AND doi = myDoi); --conto il numero di occorrenze della parola nella descrizione
                IF match >= n_parole THEN --se il numero di occorrenze è uguale al numero di parole, allora la descrizione contiene tutte le parole
                    IF regexp_count(myOutput, myDoi) = 0 THEN --se il doi non è già presente nella stringa di output
                        myOutput := myOutput || myDoi || '+'; --aggiungo il doi alla stringa di output
                    END IF;
                END IF;
            END LOOP;
        END LOOP;
        myOutput=rtrim(myOutput,'+'); --rimuovo l'ultimo '@' dalla stringa di output
        RAISE NOTICE 'es4: {%}', myOutput;
        close curs_doi;
        RETURN myOutput;
    END;
    $$;

alter function es4(text) owner to postgres;

