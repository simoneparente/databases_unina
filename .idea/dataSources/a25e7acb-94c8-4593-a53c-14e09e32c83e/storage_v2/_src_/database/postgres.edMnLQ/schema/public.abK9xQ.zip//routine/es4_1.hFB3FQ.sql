create function es4_1(myinput text) returns text
    language plpgsql
as
$$
    DECLARE
        match int;
        myOutput text:= '';
        myParola r.parolechiave.parola%TYPE;
        n_parole int;
        n_doi int := (SELECT COUNT(doi) FROM r.descrizione);
        myDoi r.articolo.doi%TYPE;
        curs_doi cursor for select doi from r.descrizione;
        sql text;
    BEGIN
        FOR myParola IN SELECT parola FROM r.parolechiave LOOP
            match := 0;
            FOR myDoi IN curs_doi LOOP
                sql := 'SELECT COUNT(*) FROM r.descrizione WHERE doi = ''' || myDoi || ''' AND r.descrizione LIKE ''%' || myParola || '%''';
                EXECUTE sql INTO match;
                IF match > 0 THEN
                    INSERT INTO r.articolo VALUES (myDoi, myParola);
                END IF;
            END LOOP;
        END LOOP;
        RETURN sql;
    END $$;

alter function es4_1(text) owner to postgres;

