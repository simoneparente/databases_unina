create procedure f2_figli(IN tagalbum integer)
    language plpgsql
as
$$
    DECLARE
        prendiFigli CURSOR FOR (SELECT codA FROM f.album AS A WHERE A.inalbum=tagalbum);
        numFigli INTEGER = (SELECT Count(*) FROM f.album AS A WHERE A.inalbum=tagalbum);
        figlio f.album.coda%TYPE;
    BEGIN
        FETCH prendiFigli INTO figlio;
        IF numFigli>0 THEN
            FOR i IN 1..numFigli LOOP
                FETCH prendiFigli INTO figlio;
                RAISE NOTICE 'figlio: %', figlio;
                CALL f2_figli(figlio);
                INSERT INTO f.tmp(codA) values (figlio);
            end loop;
        end if;
    end;
$$;

alter procedure f2_figli(integer) owner to postgres;

