create function trig1() returns trigger
    language plpgsql
as
$$
    DECLARE
        i INTEGER := 0;
        n INTEGER := (SELECT COUNT(*) FROM r.parolechiave NATURAL JOIN fascicolo);
        word r.parolechiave.parola%TYPE;
        cursore CURSOR FOR SELECT p.parola FROM r.parolechiave as p NATURAL JOIN fascicolo as f;

    BEGIN
        OPEN cursore;

        WHILE (i<n) LOOP
            FETCH cursore INTO word;
            IF (NEW.sommario LIKE '%'|| word || '%') THEN
                INSERT INTO r.descrizione(parola, doi)
                values (word, NEW.doi);
            END IF;
            i = i + 1;
        END LOOP ;
    END;
$$;

alter function trig1() owner to postgres;

